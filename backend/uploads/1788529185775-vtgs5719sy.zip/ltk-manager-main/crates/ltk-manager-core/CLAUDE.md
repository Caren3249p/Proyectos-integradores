@../../src-tauri/CLAUDE.md
